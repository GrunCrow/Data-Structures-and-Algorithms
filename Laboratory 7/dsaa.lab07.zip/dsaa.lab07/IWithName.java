package dsaa.lab07;

public interface IWithName{
	String getName();
}
