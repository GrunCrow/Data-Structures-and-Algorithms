package dsaa.lab08;

public interface IWithName{
	String getName();
}