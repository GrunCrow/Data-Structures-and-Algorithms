package dsaa.lab12;

import java.util.Scanner;

public class LinesReader {
		String concatLines(int howMany, Scanner scanner) {
			return null;
		}

}
